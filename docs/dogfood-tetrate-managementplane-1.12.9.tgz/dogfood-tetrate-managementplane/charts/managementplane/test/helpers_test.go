// Copyright (c) Tetrate, Inc 2024 All Rights Reserved.

package test

import (
	"fmt"
	"os"
	"strings"
	"testing"

	"github.com/stretchr/testify/require"
	"gopkg.in/yaml.v3"
	chartloader "helm.sh/helm/v3/pkg/chart/loader"
	"helm.sh/helm/v3/pkg/chartutil"
	"helm.sh/helm/v3/pkg/engine"
)

const (
	chartFile   = "../Chart.yaml"
	helpersFile = "../templates/_helpers.tpl"
)

func TestHelpersTemplate(t *testing.T) {
	baseFiles := make([]*chartloader.BufferedFile, 2)

	b, err := os.ReadFile(chartFile)
	require.NoError(t, err)
	baseFiles[0] = &chartloader.BufferedFile{Name: "Chart.yaml", Data: b}

	b, err = os.ReadFile(helpersFile)
	require.NoError(t, err)

	baseFiles[1] = &chartloader.BufferedFile{Name: "templates/helpers.tpl", Data: b}

	eng := engine.New(nil)

	for _, tcName := range []string{
		"postgres-password-from-secret",
		"postgres-config",
	} {
		t.Run(tcName, func(t *testing.T) {
			srcBytes, err := os.ReadFile(fmt.Sprintf("testdata/%s.yaml", tcName))
			require.NoError(t, err)

			testFile := fmt.Sprintf("templates/%s.yaml", tcName)
			bfFiles := append(baseFiles, &chartloader.BufferedFile{Name: testFile, Data: srcBytes})

			chart, err := chartloader.LoadFiles(bfFiles)
			require.NoError(t, err)

			var renderedValues chartutil.Values
			valuesByes, err := os.ReadFile(fmt.Sprintf("testdata/%s-values.yaml", tcName))
			if err == nil { // only add values if supplied in the current test case
				values := make(map[string]interface{})
				require.NoError(t, yaml.Unmarshal(valuesByes, values))
				renderedValues, err = chartutil.ToRenderValues(chart, values, chartutil.ReleaseOptions{Name: "test"}, nil)
				require.NoError(t, err)
			}

			outFiles, err := eng.Render(chart, renderedValues)
			require.NoError(t, err)

			expBytes, err := os.ReadFile(fmt.Sprintf("testdata/%s-output.yaml", tcName))
			require.NoError(t, err)

			for name, data := range outFiles {
				if strings.HasSuffix(name, testFile) {
					require.Equal(t, string(expBytes), data)
					return
				}
			}
			require.Fail(t, "no rendered file found to be verified", testFile)
		})
	}
}
