// Copyright (c) Tetrate, Inc 2024 All Rights Reserved.

package test

import (
	"embed"
	"testing"

	"github.com/stretchr/testify/require"
	"helm.sh/helm/v3/pkg/chart/loader"

	"github.com/tetrateio/tetrate/helm/pkg/test"
)

var (
	//go:embed cases
	casesDir embed.FS
	//go:embed default-expected
	defaultDir embed.FS

	testCases []test.RenderTestCase
)

func TestMain(m *testing.M) {
	test.RunTestMain(m, defaultDir, casesDir, &testCases)
}

func TestRenderManagementPlaneChart(t *testing.T) {
	err := test.LoadDependencies("..")
	require.NoError(t, err)

	c, err := loader.LoadDir("..")
	require.NoError(t, err)

	test.RunRenderChartTest(t, c, testCases)
}
